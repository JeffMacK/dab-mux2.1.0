#! /bin/sh

autoreconf --install && \
    echo "You can call ./configure now"
