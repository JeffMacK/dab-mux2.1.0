Convert an ZeroMQ stream to EDI
===============================

This *zmq2edi* tool can receive a ZMQ ETI stream from
ODR-DabMux and generate and EDI stream.

Quite useful if your modulator wants EDI input, and your network is not good
enough making you want to use something based on TCP.
