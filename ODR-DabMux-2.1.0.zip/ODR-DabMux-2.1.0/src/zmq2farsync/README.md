Drive a Farsync card from a ZMQ ETI stream
==========================================

This *zmq2farsync* tool can receive a ZMQ ETI stream from
ODR-DabMux and drive a Farsync card with it.
